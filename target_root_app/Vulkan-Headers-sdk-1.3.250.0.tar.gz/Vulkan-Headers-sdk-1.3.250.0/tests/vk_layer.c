#include "vulkan/vk_layer.h"

int foobar()
{
    return 0;
}
