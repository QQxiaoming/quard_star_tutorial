# Loader Specification and Interfaces
See the [LoaderInterfaceArchitecture.md](../docs/LoaderInterfaceArchitecture.md) for detailed documentation.

# Building
Builds for Linux, Windows, and MacOS are supported via CMake. See top level BUILD.md file.
