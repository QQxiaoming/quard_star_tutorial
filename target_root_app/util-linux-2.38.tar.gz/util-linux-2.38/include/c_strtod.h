#ifndef UTIL_LINUX_C_STRTOD_H
#define UTIL_LINUX_C_STRTOD_H

extern double c_strtod(char const *str, char **end);

#endif
